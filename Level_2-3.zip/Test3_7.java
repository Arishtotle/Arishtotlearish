import java.util.*;

public class Test3_7{
	public static void main(String[] args){
	Scanner sc=new Scanner(System.in);
	double hr=sc.nextDouble();
	double min=sc.nextDouble();
	hr=hr*30;
	min=60-min;
	min=min*6;
	double out=0;
	
	 out=360-min-hr;
	
	System.out.println(out/2);
	}
}