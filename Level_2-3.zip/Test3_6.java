import java.util.*;

public class Test3_6{
	public static void main(String[] argr){
	Scanner sc=new Scanner(System.in);
int n=sc.nextInt();
while(n>9){
	int rem=0,sum=0;
	while(n>0){
	 rem=n%10;
	 sum+=rem*rem;
	n=n/10;
	}
	n=sum;
}	
if(n%2==1){
	System.out.println("happy number ");
}else{
	System.out.println("not happy number ");
}
	}
}