import java.util.*;

public class Test3_1{
	public static void main(String[] args){
	Scanner sc=new Scanner(System.in);	
	int n=sc.nextInt();
	if(n%2==1){
		for(int i=n-1;i>=0;i--){
			for(int j=0;j<i;j++){
				System.out.print(" ");
			}
			for(int j=0;j<n-i;j++){
				System.out.print("* ");
			}
			System.out.println();
		}
		System.out.println();
		int m=n/2;
		m=m+1;
		for(int i=m-1;i>=0;i--){
			for(int j=0;j<=i;j++){
				System.out.print(" ");
			}
			for(int j=0;j<m-i;j++){
				System.out.print("R ");
			}
			System.out.println();
		}
		for(int i=1;i<m;i++){
			for(int j=0;j<=i;j++){
				System.out.print(" ");
			}
			for(int j=0;j<m-i;j++){
				System.out.print("R ");
			}
			System.out.println();
		}
		
	}else{
		System.out.println("please enter the number as odd");
	}
	
	}
}