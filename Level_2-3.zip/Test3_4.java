import java.util.*;

public class Test3_4{
	public static void main(String[] args){
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		int[] ar=new int[n];
		for(int i=0;i<n;i++) ar[i]=sc.nextInt();
	
	for(int i=0;i<n;i++){
	for(int j=i+1;j<n;j++){
	for(int k=i;k<=j;k++){
		if(ar[i]+ar[j]+ar[k]==0){
			System.out.println(ar[i]+""+ar[j]+""+ar[k]);
		}
	}
	}
	}
	
	}
}