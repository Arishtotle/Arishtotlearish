public class Test3_3{
	public static void main(String[] args){
		String[] s={"one","two","three","four","five","six","seven","eight","nine","ten"};
		char[] ch={'w','o','n','o','i'};
		for(int i=0;i<s.length;i++){
			int count=0;
			int n=s[i].length();
			
			for(int j=0;j<n;j++){
				for(int k=0;k<ch.length;k++){
					if(j<n && s[i].charAt(j)==ch[k]){
						count++;
						break;
					}
			}
			}
			if(count==n){
				System.out.println(s[i]);
			}
		}
	}
}