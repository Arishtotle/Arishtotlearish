import java.util.*;

public class Test3_5{
	public static int fun(int n){
		int sum=0;
	if(n<=9){
		return n;
	}
	
	if(n>9)
	{		while(n>0){
	int rem=n%10;
	 sum+=rem;
	n=n/10;
		}
		n=sum;
	 return fun(n);
	}
	return -1;
	}
	public static void main(String[] args){
	Scanner sc=new Scanner(System.in);	
	int n=sc.nextInt();
	if(n>0){
	System.out.println(fun(n));
	}else{
		System.out.println("please enter the vale in positive");
	}
	}
}